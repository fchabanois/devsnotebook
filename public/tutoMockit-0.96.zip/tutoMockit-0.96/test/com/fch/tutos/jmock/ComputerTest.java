package com.fch.tutos.jmock;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.junit.Assert;
import org.junit.Test;

import com.fch.tutos.jmock.Computer;
import com.fch.tutos.jmock.IHistoryManager;

public class ComputerTest {

	// =========================================================================
	// Tests for add(int,int)
	// =========================================================================

	@Test
	public void testAdd_nominalCase() {
		Computer computer = new Computer();
		final int a = 3;
		final int b = 2;
		Mockery context = new Mockery();
		final IHistoryManager historyManager = context.mock(IHistoryManager.class);
		computer.setHistoryManager(historyManager);

		context.checking(new Expectations() {

			{
				one(historyManager).logAddition(a, b);
			}
		});
		
		int result = computer.add(a, b);

		context.assertIsSatisfied();
		int expectedResult = 5;
		Assert.assertEquals("resultat", expectedResult, result);
	}
	
	// =========================================================================
	// Tests for add(String,String)
	// =========================================================================

	@Test
	public void testAddStrings_nominalCase() {
		Computer computer = new Computer();
		String a = "3";
		String b = "2";

		String result = computer.add(a, b);

		String expectedResult = "5";
		Assert.assertEquals("resultat", expectedResult, result);
	}

	@Test
	public void testAddStrings_paramNull() {
		Computer computer = new Computer();
		String a = null;
		String b = "2";

		String result = computer.add(a, b);

		String expected = "";
		Assert.assertEquals("resultat", expected, result);
	}

	@Test
	public void testAddStrings_paramNotInteger() {
		Computer computer = new Computer();
		String a = "ablkjfds";
		String b = "2";

		String result = computer.add(a, b);

		String expected = "";
		Assert.assertEquals("resultat", expected, result);
	}

}
