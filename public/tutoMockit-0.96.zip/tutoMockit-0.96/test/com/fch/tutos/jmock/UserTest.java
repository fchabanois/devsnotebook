package com.fch.tutos.jmock;


public class UserTest {

}
