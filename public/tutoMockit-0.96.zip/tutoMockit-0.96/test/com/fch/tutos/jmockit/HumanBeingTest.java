package com.fch.tutos.jmockit;

import mockit.Expectations;
import mockit.Mock;
import mockit.MockClass;
import mockit.MockField;
import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

public class HumanBeingTest {
	
	@After
	public void tearDown() {
		// to avoid pertubation on other junit test
		Mockit.restoreAllOriginalDefinitions();
	}
	
	@Test
	public void testLiveYourDay() {
		HumanBeing being = new HumanBeing();
		
		new Expectations(true)
		    {
				// Mettre ici les classes que l'on veut mocker, et leurs m�thodes dans l'annotation
			
		    	@MockField(methods={"sleep"})
		    	HumanBeing mock;
		    	{
		    		// Mettre ici les expectations, ie les appels attendus
		    		
		    		mock.sleep(); 
		    	}
		    };
		    
		// La m�thode test�e
		being.liveYourDay();
		
		// V�rification des expectations
		Expectations.assertSatisfied();
	}
	
	@Test
	public void testLiveYourDay_allMocked() {
		HumanBeing being = new HumanBeing();
		
		final String aHug = "a hug";
		new Expectations(true)
		    {
				@MockField(methods={"liveYourDay"},inverse=true)
		    	HumanBeing mock;
		    	{
		    		invoke(mock, "chat");

		    		mock.goToWork();
		    		
		    		invoke(mock, "chat");
		    		
		    		mock.give("a kiss");returns(aHug);
		    		
		    		invoke(mock, "chat");
		    		
		    		mock.doSport(withAny(new String()));

		    		
		    		mock.sleep(); 
		    	}
		    };
		    
		// La m�thode test�e
		being.liveYourDay();
//		Assert.assertEquals("human's have",aHug, being.));
		
		// V�rification des expectations
		Expectations.assertSatisfied();
	}
	
//	@Ignore  ne marche pas car classe abstraite
//	public void testLiveYourDay() {
//		HumanBeing being = new HumanBeing();
//		
//		new Expectations(true)
//		    {
//		    	@MockField(methods={"eat"})
//		    	AbstractLivingBeing mock;
//		    	{
//		    		mock.eat(); 
//		    	}
//		    };
//		    
//		being.liveYourDay();
//		Expectations.assertSatisfied();
//	}

	// ===============================================================================================
	// Test doSport
	// ===============================================================================================
	@Test
	public void testDoSport(){
		HumanBeing human = new HumanBeing();		
		Mockit.setUpMocks(MockHumanBeing.class);

		human.doSport();
		Mockit.assertExpectations();
	}
	
	@MockClass(realClass = HumanBeing.class)
	public static class MockHumanBeing {
		@Mock(invocations = 1)
		protected void dress(){
		}
	}
	
	public static class MockHumanBeingDress extends HumanBeing {
		static boolean dressHasBeenCalled = false;
		
		protected void dress(){
			dressHasBeenCalled = true;
		}
	}
	
	@Test
	public void testDoSport_mockMaison(){		
		HumanBeing human = new MockHumanBeingDress();
		
		human.doSport();
		
		Assert.assertTrue("dress has not been called!",MockHumanBeingDress.dressHasBeenCalled);
	}
	
	// ===============================================================================================
	// Test doSport(String)
	// ===============================================================================================
	
	@Test
	public void testDoSportWithString(){
		HumanBeing human = new HumanBeing();		
		Mockit.setUpMocks(MockHumanBeing_dressWithStringCalledOnce.class);
		MockHumanBeing_dressWithStringCalledOnce.expectedCloth = "short";

		human.doSport("basket");
		Mockit.assertExpectations();
	}
	
	@MockClass(realClass = HumanBeing.class)
	public static class MockHumanBeing_dressWithStringCalledOnce {
		static String expectedCloth;
		
		@Mock(invocations = 1)
		protected void dress(String typeOfCloth){
			Assert.assertEquals("type of cloth", expectedCloth, typeOfCloth);
		}
	}
}
