package com.fch.tutos.jmockit;

import mockit.Expectations;
import mockit.MockField;
import mockit.Mockit;

import org.junit.After;
import org.junit.Test;

public class FooTest {
	@After
	public void tearDown() {
		// to avoid pertubation on other junit test
		Mockit.restoreAllOriginalDefinitions();
	}

	@Test
	public void testAfficherXXX(){
		Foo foo = new Foo();
		
		final IToto totoToReturn = Mockit.newEmptyProxy(IToto.class);
		
		new Expectations(true)
		    {
		    	@MockField(methods={"getToto"})
		    	YYY yyy;
		    	{
		    		yyy.getToto(); returns(totoToReturn);
		    	}
		    };
		    
		// Method tested
		foo.afficherXXX();
		
		// Assertions
		Expectations.assertSatisfied();
	}
}
