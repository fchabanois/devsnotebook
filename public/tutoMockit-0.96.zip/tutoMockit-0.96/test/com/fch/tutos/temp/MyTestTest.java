package com.fch.tutos.temp;

import junit.framework.TestCase;
import mockit.Mock;
import mockit.MockClass;
import mockit.Mockit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MyTestTest extends TestCase {

	MyTest mockedClass;

	@MockClass(realClass = MyTest.class)
	public static class ReplaceMyTest {

		@Mock
		public void $init() {
		}

		@Mock
		public void $init(String value) {
		}

		@Mock
		public String publicMethod() {
			return "replaced public method";
		}
	}

	@Before
	public void setUp() throws Exception {
		Mockit.setUpMocks(ReplaceMyTest.class);
		mockedClass = new MyTest("test");
	}

	@After
	public void tearDown() throws Exception {
		Mockit.tearDownMocks();
	}

	@Test
	public void testReplacePublic() throws Exception {

		assertEquals("replaced public method", mockedClass.publicMethod());
	}

	@Test
	public void testReplaceConstructor() throws Exception {

		assertEquals(null, mockedClass.getMemberToSet());
	}

	@Test
	public void testReplaceDefaultConstructorTest() throws Exception {
		Mockit.restoreOriginalDefinition(MyTest.class);
		mockedClass = new MyTest();
		assertEquals("set by original constructor", mockedClass
				.getMemberToSet());
	}
}