package com.fch.tutos.temp;

public class MyTest {
    String memberToSet;
   
    public MyTest() {
        this.memberToSet = "set by original constructor";
    }

    public MyTest( String value ) {
        this.memberToSet = "set by original constructor" + value;
    }

    public String publicMethod(){
        return "original public method";
    }

    public String getMemberToSet(){
        return memberToSet;
    }
}
