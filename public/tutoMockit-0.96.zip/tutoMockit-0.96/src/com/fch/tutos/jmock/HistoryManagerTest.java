package com.fch.tutos.jmock;

import org.junit.Assert;
import org.junit.Test;

public class HistoryManagerTest {
	
	@Test
	public void testLogAddition() {
		HistoryManager manager = new HistoryManager();

		manager.logAddition(3, 2);

		String expectedHistory = "3 + 2\n";
		Assert.assertEquals("history", expectedHistory, manager.getHistory());
	}

}
