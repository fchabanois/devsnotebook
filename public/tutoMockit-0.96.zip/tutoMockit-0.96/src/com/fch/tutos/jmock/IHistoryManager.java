package com.fch.tutos.jmock;

public interface IHistoryManager {
	public void logAddition(int a, int b);
	
	public String getHistory();
}
