package com.fch.tutos.jmock;

public class HistoryManager implements IHistoryManager {
	protected StringBuilder history = new StringBuilder();
	
	public void logAddition(int a, int b) {
		history.append(a + " + " + b + "\n");
	}

	public String getHistory() {
		// TODO Auto-generated method stub
		return history.toString();
	}
	
	
}
