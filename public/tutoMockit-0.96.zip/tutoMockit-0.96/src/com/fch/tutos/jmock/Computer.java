package com.fch.tutos.jmock;


public class Computer {
	private IHistoryManager historyManager;

	/**
	 * @return the addition of <code>a</code> and <code>b</code>
	 */
	public int add(int a, int b) {
		int result = a + b;
		historyManager.logAddition(a, b);
		return result;
	}

	/**
	 * Compute the addition of <code>a</code> and <code>b</code>.
	 * <p>If a parameter is <code>null</code> or not a number, an empty String 
	 * is returned.</p>
	 */
	public String add(String a, String b) {
		String result = "";
		try {
			result = String.valueOf(Integer.valueOf(a) + Integer.valueOf(b));
		} catch (NumberFormatException e) {
			// do nothing
		}
//		historyManager.append(a + " + " + b + " = " + result + "\n");
		return result;
	}

	public String getHistory() {
		return historyManager.getHistory();
	}

	public IHistoryManager getHistoryManager() {
		return historyManager;
	}

	public void setHistoryManager(IHistoryManager historyManager) {
		this.historyManager = historyManager;
	}
}
