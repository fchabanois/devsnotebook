package com.fch.tutos.jmockit;

import java.util.ArrayList;
import java.util.List;

	public class Candidate {
		protected static List<String> minimumQualifications;
		
		static {
			minimumQualifications = new ArrayList<String>();
			minimumQualifications.add("typing");
			minimumQualifications.add("english speaking");
		}
	}
