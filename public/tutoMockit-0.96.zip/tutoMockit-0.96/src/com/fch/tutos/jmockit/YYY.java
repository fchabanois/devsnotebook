package com.fch.tutos.jmockit;

public class YYY {
	public IToto getToto(){
		return null;
	}
}
