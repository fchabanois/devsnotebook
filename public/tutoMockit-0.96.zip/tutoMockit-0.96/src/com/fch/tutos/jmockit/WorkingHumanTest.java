package com.fch.tutos.jmockit;


import mockit.Mock;
import mockit.MockClass;
import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class WorkingHumanTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() {
		// to avoid pertubation on other junit test
		Mockit.restoreAllOriginalDefinitions();
	}
	
	// ===============================================================================================
	// Test for makeDinner
	// ===============================================================================================
	@Test
	public void testMakeDinner() {
		WorkingHuman human = new WorkingHuman();
		
		Mockit.setUpMocks(MockPizza_ConstructorCalledOnce.class);
		MockPizza_ConstructorCalledOnce.expectedIngredients = Pizza.BASIC_INGREDIENTS;

		// Method tested
		human.makeDinner("monday");
		
		Mockit.assertExpectations();
	}
	
	@MockClass(realClass = Pizza.class)
	public static class MockPizza_ConstructorCalledOnce {
		static String[] expectedIngredients;
		// Can't be static !!!
		Pizza it;
		
		@Mock(invocations = 1)
		public void $init(String ... ingredients) {
			Assert.assertEquals("ingredients", expectedIngredients, ingredients);
		}
	}

	// ===============================================================================================
	// Test for makeDinner avec CORE
	// ===============================================================================================
	@Test
	public void testMakeDinner_core() {
		WorkingHuman human = new WorkingHuman();
		
		Mockit.redefineMethods(Pizza.class, MockPizza_ConstructorCore.class);
		MockPizza_ConstructorCore.expectedIngredients = Pizza.BASIC_INGREDIENTS;
		
		// Method tested
		human.makeDinner("monday");
		
	}

	public static class MockPizza_ConstructorCore {
		static String[] expectedIngredients;
		// Can't be static !!!
		Pizza it;
		
		public void $init(String ... ingredients) {
			Assert.assertEquals("ingredients", expectedIngredients, ingredients);
		}
	}
}
