package com.fch.tutos.jmockit;

public abstract class AbstractLivingBeing {
	public void eat(){		
	}
	
	abstract public void liveYourDay();
	
	public void wakeUp(){
	}
	
	public void clean(){
		
	}
	
	public void sleep() {
	}
	
	public void enjoyYourLife() {
	}
}
