package com.fch.tutos.jmockit;

public class Behavior {

}
