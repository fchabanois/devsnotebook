package com.fch.tutos.jmockit;

public class Pizza extends Food {
	public final static String[] BASIC_INGREDIENTS = new String[]{"cheese","tomato"};
	
	public Pizza(String...ingredients) {
	}
}
