package com.fch.tutos.jmockit;

public class HumanBeing extends AbstractLivingBeing {

	@Override
	public void liveYourDay() {
//		wakeUp();
//		eat();
//		clean();
		chat();
		goToWork();
		chat();
		String string = give("a kiss");
		chat();
		doSport("foot");
//		eat();
//		work();
//		getHome();
//		eat();
//		enjoyYourLife();
		sleep();
//		dress("bonjou");
		// disabler com^pilation quand error
	}
	
	
	@Override
	public void sleep() {
		// TODO Auto-generated method stub
	}

	@Override
	public void enjoyYourLife() {
		// TODO Auto-generated method stub
		
	}

	private void getHome() {
		// TODO Auto-generated method stub
		
	}

	protected void goToWork() {
		// TODO Auto-generated method stub
	}
	
	private void chat() {
		// TODO Auto-generated method stub
	}
	
	protected void doSport(){
		dress();
	}
	
	protected void dress(){
		
	}
	
	protected void doSport(String typeOfSport){
		if ("basket".equals(typeOfSport)){
			dress("short");
		}
	}
	
	protected void dress(String typeOfClothes){
		
	}
	
	protected void run(){
		
	}
	
	protected void takeAShower(){
		
	}
	
	public Object create(Object paramA, Object paramB){
		return null;
	}
	
	protected String give(String something){
		return null;
	}
}
