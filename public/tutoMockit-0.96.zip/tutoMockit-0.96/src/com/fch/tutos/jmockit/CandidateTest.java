package com.fch.tutos.jmockit;

import java.util.List;

import mockit.Mock;
import mockit.MockClass;
import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Test;


/**
 * @author Florence
 *
 */
public class CandidateTest {
	@After
	public void tearDown() {
		// to avoid pertubation on other junit test
		Mockit.restoreAllOriginalDefinitions();
	}

	// ===============================================================================================
	// Test initialiseur static avec annotation
	// ===============================================================================================
	
	@Test
	public void testPizza_staticInitWithAnnotations() throws Exception {
		
		Mockit.setUpMocks(MockCandidate_staticAnnotations.class);
		
		Candidate candidate = new Candidate();
		
		// To assert that the static initializer has been called
		Mockit.assertExpectations();
		Assert.assertEquals("qualifications mocked", null, Candidate.minimumQualifications);
		
	}

	@MockClass(realClass = Candidate.class)
	public static class MockCandidate_staticAnnotations {
		
		@Mock(invocations=1)
		void $clinit(){
			// no initialisation of qualifications
		}
	}
	
	// ===============================================================================================
	//
	// ===============================================================================================
	@Test
	public void testPizza_staticInitWithCore() throws Exception {
		Mockit.redefineMethods(Candidate.class, MockCandidate_staticCore.class);
		
		Candidate candidate = new Candidate();
		
		Assert.assertEquals("qualifications mocked", null, Candidate.minimumQualifications);
	}

	static class MockCandidate_staticCore {
		
		void $clinit(){
			// no initialisation of qualifications
		}
	}

}
