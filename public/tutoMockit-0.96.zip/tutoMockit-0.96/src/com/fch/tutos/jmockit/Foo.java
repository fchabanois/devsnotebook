package com.fch.tutos.jmockit;

public class Foo {
	private YYY yyy = new YYY();
	
	public void afficherXXX(){
		yyy.getToto();
	}

	public YYY getYyy() {
		return yyy;
	}

	public void setYyy(YYY yyy) {
		this.yyy = yyy;
	}
}
