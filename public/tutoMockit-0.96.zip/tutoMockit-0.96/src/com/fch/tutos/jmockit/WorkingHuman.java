package com.fch.tutos.jmockit;

public class WorkingHuman extends HumanBeing {
	
	public WorkingHuman() {
	}
	
	protected void makeDinner(String dayOfWeek) {
		Food food = new Pizza(Pizza.BASIC_INGREDIENTS);
	}

}
