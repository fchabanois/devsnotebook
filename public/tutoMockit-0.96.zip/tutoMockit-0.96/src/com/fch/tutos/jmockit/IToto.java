package com.fch.tutos.jmockit;

public interface IToto {
	
	public void helloTata();
	
	public void helloTiti();
	
}
