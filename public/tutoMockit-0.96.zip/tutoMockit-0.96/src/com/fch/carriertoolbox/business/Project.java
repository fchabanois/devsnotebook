package com.fch.carriertoolbox.business;

import java.util.Collection;
import java.util.Date;

/**
 * @author Florence
 * 
 */
public class Project {
	private int numberOfPeopleInvolved;

	private String roleInTheProject;

	private String description;

	private Date duration;

	private Collection<Skill> skills;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDuration() {
		return duration;
	}

	public void setDuration(Date duration) {
		this.duration = duration;
	}

	public int getNumberOfPeopleInvolved() {
		return numberOfPeopleInvolved;
	}

	public void setNumberOfPeopleInvolved(int numberOfPeopleInvolved) {
		this.numberOfPeopleInvolved = numberOfPeopleInvolved;
	}

	public String getRoleInTheProject() {
		return roleInTheProject;
	}

	public void setRoleInTheProject(String roleInTheProject) {
		this.roleInTheProject = roleInTheProject;
	}

	public Collection<Skill> getSkills() {
		return skills;
	}

	public void setSkills(Collection<Skill> skills) {
		this.skills = skills;
	}
}
