package com.fch.carriertoolbox.business;

import java.util.Collection;
import java.util.Date;

/**
 * Scholarship information : school, year
 */
public class Education {
	
	private Date startDate;

	private Date endDate;

	private School school;

	private DiplomaObtention diplomaObtention;
	
	private Collection<Skill> skills;


	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public School getSchool() {
		return school;
	}

	public void setSchool(School school) {
		this.school = school;
	}

	public Collection<Skill> getSkills() {
		return skills;
	}

	public void setSkills(Collection<Skill> skills) {
		this.skills = skills;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public DiplomaObtention getDiplomaObtention() {
		return diplomaObtention;
	}

	public void setDiplomaObtention(DiplomaObtention diplomaObtention) {
		this.diplomaObtention = diplomaObtention;
	}
}
