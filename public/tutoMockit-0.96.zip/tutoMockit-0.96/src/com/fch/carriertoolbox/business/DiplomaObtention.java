package com.fch.carriertoolbox.business;

import java.util.Date;

/**
 * Obtention of a Diploma
 * 
 */
public class DiplomaObtention {
	private Diploma diploma;

	private Date dateOfObtention;

	private String score;

	private boolean gotIt;

	public boolean isGotIt() {
		return gotIt;
	}

	public void setGotIt(boolean gotIt) {
		this.gotIt = gotIt;
	}

	public Date getDateOfObtention() {
		return dateOfObtention;
	}

	public void setDateOfObtention(Date dateOfObtention) {
		this.dateOfObtention = dateOfObtention;
	}

	public Diploma getDiploma() {
		return diploma;
	}

	public void setDiploma(Diploma diploma) {
		this.diploma = diploma;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

}
