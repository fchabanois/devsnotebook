package com.fch.carriertoolbox.business;

public enum ESkillType {
	UNDEFINED,
	MANAGEMENT,
	TECHNICAL,
	SYSTEM
}
