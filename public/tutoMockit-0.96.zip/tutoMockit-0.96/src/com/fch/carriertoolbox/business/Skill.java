package com.fch.carriertoolbox.business;

/**
 * ie Java 4, Unix santos
 * @author Florence
 *
 */
public class Skill {
	private ESkillType skillType;
	private String label;
	private String version;
	private String level;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public ESkillType getSkillType() {
		return skillType;
	}
	public void setSkillType(ESkillType skillType) {
		this.skillType = skillType;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}

}
