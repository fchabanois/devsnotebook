package com.fch.carriertoolbox.business;

import java.util.Collection;
import java.util.Date;

public class Candidate {
	
	private Collection<Experience> experiences;

	private Collection<Education> educations;

	private Collection<Wish> wishes;

	private String last_name;

	private String first_name;

	private String email;

	private Date birth;

	// Utile?
	public Collection<Profile> profile;

	public Date getBirth() {
		return birth;
	}

	public void setBirth(Date birth) {
		this.birth = birth;
	}

	public Collection<Education> getEducations() {
		return educations;
	}

	public void setEducations(Collection<Education> educations) {
		this.educations = educations;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Collection<Experience> getExperiences() {
		return experiences;
	}

	public void setExperiences(Collection<Experience> experiences) {
		this.experiences = experiences;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public Collection<Profile> getProfile() {
		return profile;
	}

	public void setProfile(Collection<Profile> profile) {
		this.profile = profile;
	}

	public Collection<Wish> getWishes() {
		return wishes;
	}

	public void setWishes(Collection<Wish> wishes) {
		this.wishes = wishes;
	}
}
