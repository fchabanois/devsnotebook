package com.fch.carriertoolbox.business;

public enum EDiplomaType {
	MBA,
	MASTER,
	LICENSE,
	DEUG,
	DULCO,
	BTS,
	DUT,
	BAC,
	BEP
}
