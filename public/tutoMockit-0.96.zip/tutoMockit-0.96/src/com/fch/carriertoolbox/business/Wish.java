package com.fch.carriertoolbox.business;

public class Wish {

}
