package com.fch.carriertoolbox.business;

/**
 * A diploma
 */
public class Diploma {
	
	private EDiplomaType diplomaType;
	
	private String name;

	private String abbreviation;

	private String about;

	public String getAbbreviation() {
		return abbreviation;
	}

	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public EDiplomaType getDiplomaType() {
		return diplomaType;
	}

	public void setDiplomaType(EDiplomaType diplomaType) {
		this.diplomaType = diplomaType;
	}

}
