package com.fch.carriertoolbox.business;

/**
 * A profil to display to the recruiter : some wishes display, more details or not, 
 * 	a different title, different skill hightlighted
 * 
 * For example : more techos, more management
 * 
 * �tendre de candidat?
 *
 */
public class Profile {
	private String jobTitle;
}
