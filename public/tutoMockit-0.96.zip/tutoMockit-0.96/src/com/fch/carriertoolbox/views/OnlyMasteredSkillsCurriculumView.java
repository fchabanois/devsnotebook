package com.fch.carriertoolbox.views;

import com.fch.carriertoolbox.business.Candidate;

public class OnlyMasteredSkillsCurriculumView implements ICurriculumView {

	public void view(Candidate candidate) {
		// TODO Auto-generated method stub

	}

}
