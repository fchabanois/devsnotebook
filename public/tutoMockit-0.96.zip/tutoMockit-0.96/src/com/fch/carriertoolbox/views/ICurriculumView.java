package com.fch.carriertoolbox.views;

import com.fch.carriertoolbox.business.Candidate;

public interface ICurriculumView {
	public void view(Candidate candidate);

}
