package com.fch.carriertoolbox.views;

import com.fch.carriertoolbox.business.Candidate;

public class DetailedCurriculumView implements ICurriculumView {

	public void view(Candidate candidate) {
		// TODO Auto-generated method stub

	}

}
