==============================================================================
== Script name : sql_plus_remote_launcher v1.0
==============================================================================
Created on August 2009
Downloaded from http://fch.blog.free.fr
==============================================================================

=== Compatibility ===
Only for oracle databases.
The script only works on Windows.

=== DESCRIPTION ===
This script allow you to run a bunch of SQL scripts in several databases without opening a session for each of them with toad.

=== HOW TO ===
1. put the SQL scripts in the scripts_to_launch directory

2. configure the file oracle_instances.conf with the instances where you want to deploy your scripts. These instances are defined in your tnsnames.ora file. 
Note that you can use "#" to comment an instance.

	LOGIN1/PASSWORD@MY_INSTANCE
	#LOGIN1/PASSWORD@MY_INSTANCE
	LOGIN1/PASSWORD@MY_INSTANCE_2

3. open a dos command

4. navigate to directory containing the script launcher.bat

	cd D:\Aden\oracle\sqlplus-remote-launcher

5. run the script

6. answer the question. They are asked to prevent any unfortunate configuration.

7. that's it !



